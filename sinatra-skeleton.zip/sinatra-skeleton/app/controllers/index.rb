get '/' do
	erb :index
end
